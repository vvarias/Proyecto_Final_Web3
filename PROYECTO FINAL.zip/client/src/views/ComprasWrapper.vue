<template>
  <Compras />
</template>

<script setup>
import Compras from '../components/Compras.vue'
</script>
