//src/views/GastosWrapper.vue
<template>
  <Gastos />
</template>

<script setup>
import Gastos from '../components/Gastos.vue'
</script>