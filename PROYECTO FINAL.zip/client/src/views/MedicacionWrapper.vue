//src/views/MedicacionWrapper.vue
<template>
  <Medicacion />
</template>

<script setup>
import Medicacion from '../components/Medicacion.vue'
</script>